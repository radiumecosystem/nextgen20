'use client'

import Layout from '../components/layout'
import Tasks from '../components/tasks'

export default function Page() {
  return (
    <Layout>
      <Tasks />
    </Layout>
  )
}