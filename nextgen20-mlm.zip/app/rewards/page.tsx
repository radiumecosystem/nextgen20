'use client'

import Layout from '../components/layout'
import Rewards from '../components/rewards'

export default function Page() {
  return (
    <Layout>
      <Rewards />
    </Layout>
  )
}