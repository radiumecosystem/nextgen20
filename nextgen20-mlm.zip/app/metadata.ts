'use client'

import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'NextGen20 MLM Platform',
  description: 'Your gateway to financial growth and network marketing success',
}